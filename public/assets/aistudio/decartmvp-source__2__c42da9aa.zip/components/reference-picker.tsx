"use client";

import { useEffect, useRef, useState, type ChangeEvent } from "react";

export interface SelectedReference {
  id: string;
  name: string;
  src: string;
  blob: Blob;
  source: "preset" | "upload";
  promptSuggestion?: string;
}

const PRESETS = [
  {
    id: "bomber",
    name: "Bomber",
    src: "/manus-storage/decart-bomber_d6feb0b3.webp",
    prompt: "Substitute the current top with a black bomber jacket with a clean modern fit",
  },
  {
    id: "hoodie",
    name: "Hoodie",
    src: "/manus-storage/decart-hoodie_19d9f074.webp",
    prompt: "Substitute the current top with a navy blue hoodie with a relaxed fit",
  },
  {
    id: "cap",
    name: "Cap",
    src: "/manus-storage/decart-cap_490e47b1.webp",
    prompt: "Add a dark baseball cap to the person's head",
  },
  {
    id: "crewneck",
    name: "Crewneck",
    src: "/manus-storage/decart-crewneck_0d680341.webp",
    prompt: "Substitute the current top with a soft grey crewneck sweatshirt",
  },
  {
    id: "rain-shell",
    name: "Rain shell",
    src: "/manus-storage/decart-rainjacket_4642d8d2.webp",
    prompt: "Substitute the current top with a bright yellow hooded rain shell",
  },
];

interface ReferencePickerProps {
  selected: SelectedReference | null;
  isLive: boolean;
  isBusy: boolean;
  isApplied: boolean;
  onSelect: (reference: SelectedReference) => void;
  onApply: () => void;
  onClear: () => void;
}

export function ReferencePicker({ selected, isLive, isBusy, isApplied, onSelect, onApply, onClear }: ReferencePickerProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [loadingPreset, setLoadingPreset] = useState<string | null>(null);
  const [message, setMessage] = useState("");

  useEffect(() => {
    const preview = selected?.source === "upload" ? selected.src : null;
    return () => {
      if (preview) URL.revokeObjectURL(preview);
    };
  }, [selected]);

  async function choosePreset(preset: (typeof PRESETS)[number]) {
    setLoadingPreset(preset.id);
    setMessage("");
    try {
      const response = await fetch(preset.src);
      if (!response.ok) throw new Error("This preset could not be loaded. Try another image.");
      const blob = await response.blob();
      onSelect({ id: preset.id, name: preset.name, src: preset.src, blob, source: "preset", promptSuggestion: preset.prompt });
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Could not load this preset.");
    } finally {
      setLoadingPreset(null);
    }
  }

  function chooseUpload(event: ChangeEvent<HTMLInputElement>) {
    const file = event.currentTarget.files?.[0];
    event.currentTarget.value = "";
    setMessage("");
    if (!file) return;
    if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) {
      setMessage("Choose a PNG, JPEG, or WebP image.");
      return;
    }
    if (file.size > 12 * 1024 * 1024) {
      setMessage("Choose an image smaller than 12 MB.");
      return;
    }
    const previewUrl = URL.createObjectURL(file);
    onSelect({ id: `upload-${crypto.randomUUID()}`, name: file.name, src: previewUrl, blob: file, source: "upload" });
  }

  return (
    <section className="panel reference-panel">
      <div className="panel-title-row">
        <div><p className="eyebrow">STEP 04 / REFERENCE</p><h2>Bring an image</h2></div>
        <span className="panel-index">OPTIONAL</span>
      </div>
      <p className="reference-intro">When applied, the image is sent to Decart for processing; this app does not persist uploads. Outfit presets are tuned for Lucy VTON.</p>

      {selected && (
        <div className="selected-reference">
          <img src={selected.src} alt={`Selected reference: ${selected.name}`} />
          <div className="selected-reference-copy"><span className="eyebrow">SELECTED {selected.source === "upload" ? "· SESSION ONLY" : "· PRESET"}</span><strong>{selected.name}</strong></div>
          <button type="button" className="clear-reference" onClick={onClear} aria-label="Clear reference image">×</button>
        </div>
      )}

      <div className="preset-row" aria-label="Bundled reference presets">
        {PRESETS.map((preset) => (
          <button
            type="button"
            className={`preset-tile ${selected?.id === preset.id ? "preset-selected" : ""}`}
            key={preset.id}
            onClick={() => void choosePreset(preset)}
            disabled={loadingPreset !== null}
            aria-pressed={selected?.id === preset.id}
          >
            <span className="preset-image-wrap"><img src={preset.src} alt="" loading="lazy" />{loadingPreset === preset.id && <span className="preset-loading" />}</span>
            <span className="preset-name">{preset.name}</span>
          </button>
        ))}
      </div>

      <div className="reference-actions">
        <input ref={fileInputRef} className="visually-hidden" type="file" accept="image/png,image/jpeg,image/webp" onChange={chooseUpload} aria-label="Upload a reference image" />
        <button className="button-upload" type="button" onClick={() => fileInputRef.current?.click()}>
          <span className="upload-plus">+</span> Upload from device
        </button>
        {selected && (isLive ? (
          <button className={`button-secondary ${isApplied ? "button-applied" : ""}`} type="button" onClick={onApply} disabled={isBusy || isApplied}>
            {isBusy ? "Applying…" : isApplied ? "Image applied" : "Apply image"}<span aria-hidden="true">↗</span>
          </button>
        ) : <span className="reference-ready">Ready for session</span>)}
      </div>
      {message && <p className="reference-error" role="alert">{message}</p>}
      {selected?.source === "upload" && <p className="session-only-note">This upload stays in browser memory until used and is cleared when the session ends; applying it sends it to Decart.</p>}
      {isLive && selected && !isApplied && <p className="session-only-note">Your selection is ready. Apply it to update the current output.</p>}
      <button className="clear-text-button" type="button" onClick={onClear} disabled={!selected && !isApplied}>Clear reference</button>
    </section>
  );
}
