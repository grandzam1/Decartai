"use client";

import { createDecartClient, models, type DecartSDKError, type RealTimeClient } from "@decartai/sdk";
import { useCallback, useEffect, useRef, useState } from "react";
import { ReferencePicker, type SelectedReference } from "./reference-picker";

type ModelId = "lucy-2.6" | "lucy-vton-3.6" | "lucy-restyle-2";
type ConnectionStatus = "idle" | "requesting-camera" | "connecting" | "connected" | "generating" | "reconnecting" | "disconnected" | "error";

const MODEL_OPTIONS: { id: ModelId; name: string; description: string; short: string }[] = [
  { id: "lucy-2.6", name: "Lucy 2.6", description: "General live edits", short: "Transform a scene" },
  { id: "lucy-vton-3.6", name: "Lucy VTON 3.6", description: "Realtime virtual try-on", short: "Try a new look" },
  { id: "lucy-restyle-2", name: "Lucy Restyle 2", description: "Restyle your video", short: "Shift the visual style" },
];

const client = createDecartClient({
  apiKeyProvider: async () => {
    const response = await fetch("/api/realtime-token", { method: "POST" });
    const body = (await response.json()) as { apiKey?: string; error?: string };
    if (!response.ok || !body.apiKey) {
      throw new Error(body.error || `Token request failed (${response.status})`);
    }
    return body.apiKey;
  },
});

function getModel(id: ModelId) {
  switch (id) {
    case "lucy-2.6": return models.realtime("lucy-2.6");
    case "lucy-vton-3.6": return models.realtime("lucy-vton-3.6");
    case "lucy-restyle-2": return models.realtime("lucy-restyle-2");
  }
}

function errorText(error: unknown): string {
  if (error instanceof Error) return error.message;
  const sdkError = error as Partial<DecartSDKError>;
  return sdkError?.code ? `${sdkError.code}: ${sdkError.message}` : String(error);
}

function statusLabel(status: ConnectionStatus): string {
  switch (status) {
    case "requesting-camera": return "Requesting camera";
    case "connecting": return "Connecting to Decart";
    case "connected": return "Live and transforming";
    case "generating": return "Generating live output";
    case "reconnecting": return "Reconnecting";
    case "disconnected": return "Session ended";
    case "error": return "Connection issue";
    default: return "Ready when you are";
  }
}

function CameraGlyph() {
  return <svg aria-hidden="true" viewBox="0 0 24 24" className="control-glyph"><rect x="3" y="6" width="13" height="12" rx="3"/><path d="m16 10 5-3v10l-5-3"/></svg>;
}

function MicGlyph() {
  return <svg aria-hidden="true" viewBox="0 0 24 24" className="control-glyph"><rect x="9" y="3" width="6" height="12" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3m-4 0h8"/></svg>;
}

export default function VideoStream() {
  const inputRef = useRef<HTMLVideoElement>(null);
  const previewRef = useRef<HTMLVideoElement>(null);
  const outputRef = useRef<HTMLVideoElement>(null);
  const realtimeClientRef = useRef<RealTimeClient | null>(null);
  const cameraRef = useRef<MediaStream | null>(null);
  const attemptRef = useRef(0);
  const appliedPromptRef = useRef("A cinematic soft-focus portrait with natural light");
  const appliedImageRef = useRef<Blob | null>(null);

  const [selectedModel, setSelectedModel] = useState<ModelId>("lucy-2.6");
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [cameraOn, setCameraOn] = useState(false);
  const [micOn, setMicOn] = useState(false);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [isLive, setIsLive] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [status, setStatus] = useState<ConnectionStatus>("idle");
  const [draftPrompt, setDraftPrompt] = useState("A cinematic soft-focus portrait with natural light");
  const [promptBusy, setPromptBusy] = useState(false);
  const [referenceBusy, setReferenceBusy] = useState(false);
  const [selectedReference, setSelectedReference] = useState<SelectedReference | null>(null);
  const [appliedReferenceId, setAppliedReferenceId] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState("");
  const [notice, setNotice] = useState("");

  useEffect(() => {
    for (const video of [inputRef.current, previewRef.current]) {
      if (video) video.srcObject = cameraStream;
    }
    if (!cameraStream && outputRef.current) outputRef.current.srcObject = null;
  }, [cameraStream, isLive]);

  useEffect(() => () => {
    attemptRef.current += 1;
    realtimeClientRef.current?.disconnect();
    for (const track of cameraRef.current?.getTracks() ?? []) track.stop();
  }, []);

  const dialSession = useCallback(async (
    stream: MediaStream,
    modelId: ModelId,
    prompt: string,
    image: Blob | null,
    attempt: number,
  ) => {
    const session = await client.realtime.connect(stream, {
      model: getModel(modelId),
      mirror: "auto",
      onRemoteStream: (transformedStream) => {
        if (outputRef.current) {
          outputRef.current.srcObject = transformedStream;
          void outputRef.current.play().catch(() => undefined);
        }
      },
      onConnectionChange: (connectionState) => setStatus(connectionState as ConnectionStatus),
      initialState: {
        prompt: { text: prompt, enhance: true },
        ...(image ? { image } : {}),
      },
    });

    if (attemptRef.current !== attempt) {
      session.disconnect();
      return false;
    }

    realtimeClientRef.current = session;
    session.on("error", (error) => {
      setErrorMessage(errorText(error));
      setStatus("error");
    });
    session.on("sessionEnded", (event) => {
      setStatus("disconnected");
      setIsLive(false);
      setErrorMessage(`Decart ended the session (${event.reason}).`);
      setAppliedReferenceId(null);
      appliedImageRef.current = null;
      setSelectedReference((current) => current?.source === "upload" ? null : current);
    });
    setIsLive(true);
    setIsConnecting(false);
    return true;
  }, []);

  async function enableCamera() {
    if (cameraRef.current) {
      for (const track of cameraRef.current.getVideoTracks()) track.enabled = true;
      setCameraOn(true);
      setErrorMessage("");
      return;
    }
    if (!navigator.mediaDevices?.getUserMedia) {
      setErrorMessage("Camera access is not available in this browser. Use a recent browser over HTTPS.");
      return;
    }
    setPreviewLoading(true);
    setStatus("requesting-camera");
    setErrorMessage("");
    setNotice("");
    const model = getModel(selectedModel);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: false,
        video: {
          width: { ideal: model.width },
          height: { ideal: model.height },
          frameRate: model.fps,
        },
      });
      cameraRef.current = stream;
      setCameraStream(stream);
      setCameraOn(true);
      setStatus("idle");
      if (micOn) {
        try {
          const audioStream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
          const audioTrack = audioStream.getAudioTracks()[0];
          if (audioTrack) {
            stream.addTrack(audioTrack);
            audioTrack.enabled = true;
          }
        } catch {
          setMicOn(false);
          setNotice("Camera is ready. Microphone permission was not granted.");
        }
      }
    } catch (error) {
      setStatus("error");
      setErrorMessage(errorText(error));
    } finally {
      setPreviewLoading(false);
    }
  }

  function toggleCamera() {
    if (!cameraRef.current) {
      void enableCamera();
      return;
    }
    const next = !cameraOn;
    for (const track of cameraRef.current.getVideoTracks()) track.enabled = next;
    setCameraOn(next);
  }

  async function toggleMicrophone() {
    const next = !micOn;
    if (!next) {
      for (const track of cameraRef.current?.getAudioTracks() ?? []) track.enabled = false;
      setMicOn(false);
      return;
    }
    if (!cameraRef.current) {
      setMicOn(true);
      setNotice("Microphone access will be requested when you enable the camera preview.");
      return;
    }

    let audioTrack = cameraRef.current.getAudioTracks()[0];
    if (!audioTrack) {
      try {
        const micStream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
        audioTrack = micStream.getAudioTracks()[0];
        if (!audioTrack) throw new Error("No microphone was found.");
        cameraRef.current.addTrack(audioTrack);
      } catch (error) {
        setErrorMessage(errorText(error));
        setMicOn(false);
        return;
      }
    }
    audioTrack.enabled = true;
    setMicOn(true);
    setNotice("");

    // If the microphone is first granted mid-call, redial once so the realtime publisher
    // includes the newly added audio track.
    if (isLive && realtimeClientRef.current && cameraRef.current) {
      const stream = cameraRef.current;
      const modelId = selectedModel;
      const prompt = appliedPromptRef.current;
      const image = appliedImageRef.current;
      realtimeClientRef.current.disconnect();
      realtimeClientRef.current = null;
      const attempt = ++attemptRef.current;
      setIsLive(false);
      setIsConnecting(true);
      setStatus("connecting");
      try {
        await dialSession(stream, modelId, prompt, image, attempt);
      } catch (error) {
        setIsConnecting(false);
        setStatus("error");
        setErrorMessage(errorText(error));
      }
    }
  }

  async function startSession() {
    const stream = cameraRef.current;
    if (!stream) {
      setErrorMessage("Enable your camera preview before starting a session.");
      return;
    }
    if (!stream.getVideoTracks().some((track) => track.enabled)) {
      setErrorMessage("Turn your camera on before starting a session.");
      return;
    }
    const prompt = draftPrompt.trim() || "Transform my live camera feed into a cinematic portrait";
    const image = selectedReference?.blob ?? null;
    const attempt = ++attemptRef.current;
    setIsConnecting(true);
    setErrorMessage("");
    setStatus("connecting");
    try {
      const connected = await dialSession(stream, selectedModel, prompt, image, attempt);
      if (connected) {
        appliedPromptRef.current = prompt;
        appliedImageRef.current = image;
        setAppliedReferenceId(selectedReference?.id ?? null);
      }
    } catch (error) {
      if (attemptRef.current !== attempt) return;
      setIsConnecting(false);
      setIsLive(false);
      setStatus("error");
      setErrorMessage(errorText(error));
    }
  }

  function endSession() {
    attemptRef.current += 1;
    realtimeClientRef.current?.disconnect();
    realtimeClientRef.current = null;
    for (const track of cameraRef.current?.getTracks() ?? []) track.stop();
    cameraRef.current = null;
    setCameraStream(null);
    setCameraOn(false);
    setMicOn(false);
    setIsConnecting(false);
    setIsLive(false);
    setStatus("idle");
    setErrorMessage("");
    setNotice("");
    setAppliedReferenceId(null);
    appliedImageRef.current = null;
    setSelectedReference((current) => current?.source === "upload" ? null : current);
    if (outputRef.current) outputRef.current.srcObject = null;
  }

  async function applyPrompt() {
    const prompt = draftPrompt.trim();
    if (!prompt) {
      setErrorMessage("Add a short description before applying the prompt.");
      return;
    }
    setPromptBusy(true);
    setErrorMessage("");
    try {
      if (isLive) {
        if (!realtimeClientRef.current?.isConnected()) throw new Error("Wait for the realtime connection before applying changes.");
        await realtimeClientRef.current.setPrompt(prompt, { enhance: true });
      }
      appliedPromptRef.current = prompt;
      setNotice(isLive ? "Prompt applied to the live session." : "Prompt saved for the next session.");
    } catch (error) {
      setErrorMessage(errorText(error));
    } finally {
      setPromptBusy(false);
    }
  }

  async function applyReference() {
    if (!selectedReference) return;
    setReferenceBusy(true);
    setErrorMessage("");
    const prompt = draftPrompt.trim() || appliedPromptRef.current;
    try {
      if (isLive) {
        if (!realtimeClientRef.current?.isConnected()) throw new Error("Wait for the realtime connection before applying an image.");
        await realtimeClientRef.current.setImage(selectedReference.blob, { prompt, enhance: true });
      }
      appliedImageRef.current = selectedReference.blob;
      appliedPromptRef.current = prompt;
      setAppliedReferenceId(selectedReference.id);
      if (prompt !== draftPrompt) setDraftPrompt(prompt);
      setNotice(isLive ? "Reference image applied to the live session." : "Reference image ready for the next session.");
    } catch (error) {
      setErrorMessage(errorText(error));
    } finally {
      setReferenceBusy(false);
    }
  }

  async function clearReference() {
    setErrorMessage("");
    try {
      if (isLive) {
        if (!realtimeClientRef.current?.isConnected()) throw new Error("Wait for the realtime connection before changing the reference.");
        await realtimeClientRef.current.setImage(null, { prompt: appliedPromptRef.current, enhance: true });
      }
      appliedImageRef.current = null;
      setAppliedReferenceId(null);
      setSelectedReference(null);
      setNotice("Reference image cleared.");
    } catch (error) {
      setErrorMessage(errorText(error));
    }
  }

  const onSelectReference = useCallback((reference: SelectedReference) => {
    setSelectedReference(reference);
    setErrorMessage("");
    if (selectedModel === "lucy-vton-3.6" && reference.promptSuggestion) {
      setDraftPrompt(reference.promptSuggestion);
    }
  }, [selectedModel]);

  const activeModel = MODEL_OPTIONS.find((option) => option.id === selectedModel) ?? MODEL_OPTIONS[0];
  const canStart = Boolean(cameraStream && cameraOn && !isLive && !isConnecting);
  const connectionClass = status === "connected" || status === "generating" ? "is-connected" : status === "error" ? "is-error" : (status === "connecting" || status === "reconnecting" || status === "requesting-camera") ? "is-waiting" : "";

  return (
    <div className="studio-app">
      <header className="topbar">
        <a className="wordmark" href="#top" aria-label="Decart live studio home">
          <img src="/decart-logo.svg" alt="Decart" className="brand-logo" />
          <span className="brand-divider" />
          <span className="wordmark-sub">LIVE STUDIO</span>
        </a>
        <div className="topbar-right">
          <span className="local-pill"><span className="local-dot" /> SESSION ONLY</span>
          <span className="topbar-caption">REALTIME CAMERA TRANSFORM</span>
        </div>
      </header>

      <main className="workspace" id="top">
        <section className="stage-column" aria-label="Video studio">
          <div className="stage-heading">
            <div>
              <p className="eyebrow">LIVE CAMERA / 01</p>
              <h1>Make the moment <em>yours.</em></h1>
            </div>
            <div className={`connection-pill ${connectionClass}`} aria-live="polite">
              <span className="connection-dot" />
              {statusLabel(status)}
            </div>
          </div>

          <section className={`video-stage ${isLive ? "stage-live" : ""}`} aria-label="Camera preview and transformed video">
            <video ref={previewRef} autoPlay muted playsInline className={`stage-video local-video ${isLive ? "is-hidden" : ""}`} />
            <video ref={outputRef} autoPlay playsInline className={`stage-video output-video ${isLive ? "" : "is-hidden"}`} />
            {!cameraStream && (
              <div className="stage-empty">
                <div className="empty-orbit"><span className="orbit-core" /><span className="orbit-ring orbit-ring-one" /><span className="orbit-ring orbit-ring-two" /></div>
                <span className="eyebrow">YOUR CAMERA STAGE</span>
                <h2>Start with a live preview</h2>
                <p>Preview is local until you start. During a session, your camera stream is sent to Decart over WebRTC for transformation.</p>
                <button className="button-primary stage-enable" type="button" onClick={() => void enableCamera()} disabled={previewLoading}>
                  {previewLoading ? "Opening camera…" : "Enable camera preview"}<span aria-hidden="true">↗</span>
                </button>
              </div>
            )}
            {cameraStream && !isLive && <div className="stage-live-label"><span className="connection-dot" /> CAMERA PREVIEW</div>}
            {isConnecting && (
              <div className="connecting-overlay" aria-live="polite">
                <span className="spinner" />
                <span>Connecting to Decart…</span>
              </div>
            )}
            {isLive && cameraStream && (
              <div className="self-preview">
                <video ref={inputRef} autoPlay muted playsInline className="self-preview-video" />
                <span className="self-preview-label">YOU</span>
              </div>
            )}
            {isLive && <div className="stage-live-label stage-live-tag"><span className="connection-dot" /> LIVE OUTPUT</div>}
            {isLive && selectedReference && appliedReferenceId === selectedReference.id && <div className="reference-live-tag">REFERENCE ACTIVE</div>}
          </section>

          <div className="stage-footer">
            <div className="stage-model-label"><span className="eyebrow">CURRENT MODEL</span><strong>{activeModel.name}</strong></div>
            <div className="stage-footer-note"><span className="signal-bars"><i /><i /><i /></span> WebRTC · Direct realtime connection</div>
          </div>

          {(errorMessage || notice) && (
            <div className={`message-banner ${errorMessage ? "message-error" : "message-notice"}`} role={errorMessage ? "alert" : "status"}>
              <span>{errorMessage || notice}</span>
              <button type="button" onClick={() => { setErrorMessage(""); setNotice(""); }} aria-label="Dismiss message">×</button>
            </div>
          )}

          <section className="prompt-panel panel">
            <div className="panel-title-row">
              <div><p className="eyebrow">DIRECT THE LOOK</p><h2>Transformation prompt</h2></div>
              <span className="panel-index">01 / PROMPT</span>
            </div>
            <label className="visually-hidden" htmlFor="live-prompt">Describe the transformation</label>
            <textarea id="live-prompt" value={draftPrompt} onChange={(event) => setDraftPrompt(event.target.value)} maxLength={500} placeholder="Describe the look you want to see…" />
            <div className="prompt-footer">
              <p>Be specific about the look, light, color, or scene. Apply changes without ending the session.</p>
              <button className="button-secondary" type="button" onClick={() => void applyPrompt()} disabled={promptBusy || !draftPrompt.trim()}>
                {promptBusy ? "Applying…" : isLive ? "Apply prompt" : "Save prompt"}<span aria-hidden="true">↗</span>
              </button>
            </div>
          </section>

          <ReferencePicker
            selected={selectedReference}
            isLive={isLive}
            isBusy={referenceBusy}
            isApplied={Boolean(selectedReference && selectedReference.id === appliedReferenceId)}
            onSelect={onSelectReference}
            onApply={() => void applyReference()}
            onClear={() => void clearReference()}
          />
        </section>

        <aside className="control-rail" aria-label="Session controls">
          <section className="panel model-panel">
            <div className="panel-title-row">
              <div><p className="eyebrow">STEP 01 / SELECT</p><h2>Choose a model</h2></div>
              <span className="panel-index">{isLive ? "LOCKED" : "3 MODELS"}</span>
            </div>
            <div className="model-list">
              {MODEL_OPTIONS.map((option, index) => (
                <button
                  className={`model-option ${selectedModel === option.id ? "model-selected" : ""}`}
                  type="button"
                  key={option.id}
                  onClick={() => setSelectedModel(option.id)}
                  disabled={isLive || isConnecting}
                  aria-pressed={selectedModel === option.id}
                >
                  <span className="model-number">0{index + 1}</span>
                  <span className="model-copy"><strong>{option.name}</strong><small>{option.description}</small></span>
                  <span className="model-radio" aria-hidden="true"><i /></span>
                </button>
              ))}
            </div>
            {isLive && <p className="inline-note">End the session to choose another model.</p>}
          </section>

          <section className="panel device-panel">
            <div className="panel-title-row">
              <div><p className="eyebrow">STEP 02 / DEVICES</p><h2>Your camera setup</h2></div>
              <span className="panel-index">LOCAL</span>
            </div>
            <div className="device-controls">
              <button className={`device-toggle ${cameraOn ? "toggle-active" : ""}`} type="button" onClick={toggleCamera} disabled={previewLoading || isConnecting} aria-pressed={cameraOn}>
                <span className="device-icon"><CameraGlyph /></span>
                <span className="device-copy"><strong>Camera</strong><small>{previewLoading ? "Opening…" : cameraOn ? "On · local preview" : cameraStream ? "Off" : "Not started"}</small></span>
                <span className={`switch ${cameraOn ? "switch-on" : ""}`}><i /></span>
              </button>
              <button className={`device-toggle ${micOn ? "toggle-active" : ""}`} type="button" onClick={() => void toggleMicrophone()} disabled={isConnecting} aria-pressed={micOn}>
                <span className="device-icon"><MicGlyph /></span>
                <span className="device-copy"><strong>Microphone</strong><small>{micOn ? "On" : "Muted"}</small></span>
                <span className={`switch ${micOn ? "switch-on" : ""}`}><i /></span>
              </button>
            </div>
            <p className="inline-note">During a session, your camera stream goes to Decart. Microphone audio is sent only while enabled; no other caller joins this MVP.</p>
          </section>

          <section className="session-action panel">
            <div className="action-topline"><span className="eyebrow">STEP 03 / GO LIVE</span><span className="session-number">{isLive ? "IN SESSION" : "READY"}</span></div>
            <h2>{isLive ? "Your look, in motion." : "Ready to transform?"}</h2>
            <p>{isLive ? "Your live output is active. Prompt and reference changes can be applied without reconnecting." : "Start a realtime session with Decart using your chosen model and prompt."}</p>
            {isLive ? (
              <button className="button-end" type="button" onClick={endSession}><span className="end-square" /> End session</button>
            ) : (
              <button className="button-primary start-session" type="button" onClick={() => void startSession()} disabled={!canStart}>
                {isConnecting ? "Connecting…" : "Start AI session"}<span aria-hidden="true">↗</span>
              </button>
            )}
            {!cameraStream && <p className="action-hint">Enable your camera preview to begin.</p>}
            {cameraStream && !cameraOn && !isLive && <p className="action-hint">Turn your camera on before starting.</p>}
          </section>

          <div className="mvp-note"><span className="note-mark">i</span><p><strong>Built for one camera.</strong> Decart transforms your feed; this MVP does not include another caller or meeting room.</p></div>
        </aside>
      </main>

      <footer className="site-footer"><span>DECART REALTIME / MVP</span><span>Camera transformations, in the moment.</span><span>NO RECORDINGS · NO ACCOUNT</span></footer>
    </div>
  );
}
