export default {
  logoUrl: "https://upload.wikimedia.org/wikipedia/commons/9/9a/Decart_Logo.svg",
};
