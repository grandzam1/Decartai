import { createDecartClient } from "@decartai/sdk";
import { NextResponse } from "next/server";

const ALLOWED_MODELS = ["lucy-2.6", "lucy-vton-3.6", "lucy-restyle-2"];

export async function POST() {
  const apiKey = process.env.DECART_API_KEY;
  if (!apiKey) {
    return NextResponse.json({ error: "DECART_API_KEY is not set on the server." }, { status: 500 });
  }

  try {
    const client = createDecartClient({ apiKey });
    const token = await client.tokens.create({ expiresIn: 60, allowedModels: ALLOWED_MODELS });
    return NextResponse.json(token);
  } catch (error) {
    console.error("Failed to create Decart client token:", error);
    return NextResponse.json({ error: "Could not create a Decart session token." }, { status: 502 });
  }
}
