import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Decart Live Studio — Realtime AI Camera",
  description: "A private realtime camera transformation studio powered by Decart.",
  applicationName: "Decart Live Studio",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
